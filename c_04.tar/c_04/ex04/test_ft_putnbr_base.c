/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_putnbr_base.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/20 14:48:00 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/20 16:49:37 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <string.h>

void	ft_putnbr_base(int nbr, char *base);

int	main(void)
{
	write(1, "42 en base 10:", strlen("42 en base 10:"));
	ft_putnbr_base(42, "0123456789");
	write(1, "\n2a == 42 en base 16:", strlen("\n2a == 42 en base 16:"));
	ft_putnbr_base(42, "0123456789abcdef");
	write(1, "\n-2a == -42 en base 16:", strlen("\n-2a == -42 en base 16:"));
	ft_putnbr_base(-42, "0123456789abcdef");
	write(1, "\n (42 en base vide):", strlen("\n (42 en base vide):"));
	ft_putnbr_base(42, "");
	write(1, "\n (42 en base de taille 1):", strlen("\n (42 en base de taille 1):"));
	ft_putnbr_base(42, "0");
	write(1, "\n (42 en base 16 avec + et -):", strlen("\n (42 en base 16 avec + et -):"));
	ft_putnbr_base(42, "+-0123456789abcdef");
	write(1, "\n (42 en base 16 avec une tabulation):", strlen("\n (42 en base 16 avec une tabulation):"));
	ft_putnbr_base(42, "\t0123456789abcdef");
	write(1, "\n101010 == 42 en base 2:", strlen("\n101010 == 42 en base 2:"));
	ft_putnbr_base(42, "01");
	write(1, "\nvn == 42 en base 8 (\"poneyvif\"):", strlen("\nvn == 42 en base 8 (\"poneyvif\"):"));
	ft_putnbr_base(42, "poneyvif");
}
