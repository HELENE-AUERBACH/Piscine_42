/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/20 14:09:00 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/20 16:23:05 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stddef.h>
#include <limits.h>
#include <unistd.h>

int	ft_error_or_strlen(const char *str)
{
	int	result;
	int	i;

	result = -1;
	i = 0;
	while (str && str[i] != '\0')
	{
		if (str[i] == ' ' || str[i] == '\f'
			|| str[i] == '\n' || str[i] == '\r'
			|| str[i] == '\t' || str[i] == '\v')
			return (0);
		i++;
	}
	result = i;
	return (result);
}

int	ft_checked_into_base(char *characters_for_base, char c, int base_len)
{
	int	i;
	int	result;

	result = 0;
	if (characters_for_base && c != '\0' && base_len > 0)
	{
		i = 0;
		while (i < base_len && characters_for_base[i])
		{
			if (c == characters_for_base[i])
				return (0);
			i++;
		}
		result = i == base_len;
	}
	return (result);
}

int	ft_error_or_correct_base(const char *str, int base_len)
{
	int		i;
	char	*characters_for_base;

	characters_for_base = (char *) malloc(base_len * sizeof(char));
	if (characters_for_base && str)
	{
		i = 0;
		while (i < base_len)
		{
			if (str[i] == '+' || str[i] == '-'
				|| (i > 0 && str[i]
					&& !ft_checked_into_base(characters_for_base, str[i], i)))
				return (0);
			else if (str[i] != '\0')
			{
				characters_for_base[i] = str[i];
				i++;
			}
		}
		free(characters_for_base);
		if (i == base_len)
			return (base_len);
	}
	return (0);
}

int	ft_error_or_base(const char *str)
{
	int	base_len;

	base_len = ft_error_or_strlen(str);
	if (base_len < 2)
		return (0);
	return (ft_error_or_correct_base(str, base_len));
}

void	ft_putnbr_base(int nbr, char *base)
{
	int		base_len;
	long	nbr_in_long;

	base_len = ft_error_or_base(base);
	if (base_len)
	{
		if (nbr >= INT_MIN && nbr <= INT_MAX)
		{
			nbr_in_long = nbr;
			if (nbr_in_long < 0)
			{
				write(1, "-", 1);
				nbr_in_long = nbr_in_long * -1;
			}
			if (nbr_in_long < base_len)
			{
				write(1, &base[nbr_in_long], 1);
			}
			else
			{
				ft_putnbr_base(nbr_in_long / base_len, base);
				ft_putnbr_base(nbr_in_long % base_len, base);
			}
		}
	}
}
