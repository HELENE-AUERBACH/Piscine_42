/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_putstr.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/18 19:25:38 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/20 09:29:13 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stddef.h>

void	ft_putstr(char *str);

int	main(void)
{
	ft_putstr(NULL);
	ft_putstr("La chaine qui suit est vide.\n");
	ft_putstr("");
	ft_putstr("\n");
	ft_putstr(" ~\n  !@42\\'`\";:.,/?+-()*&^%$#=[]{}\vest trop\tbIZaRRE");
	char s1[] = "Suc";
	char s2[] = "cess\n";
	ft_putstr(s1);
	ft_putstr(s2);
	return (0);
}
