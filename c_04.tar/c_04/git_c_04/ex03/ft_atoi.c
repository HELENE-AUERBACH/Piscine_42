/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/20 08:40:20 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/20 09:52:25 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <limits.h>

unsigned int	ft_spaces_truncating(const char *str)
{
	unsigned int	i;

	i = 0;
	if (str)
	{
		while (i <= INT_MAX && str[i]
			&& (str[i] == ' ' || str[i] == '\f'
				|| str[i] == '\n' || str[i] == '\r'
				|| str[i] == '\t' || str[i] == '\v'))
			i++;
		while (i <= INT_MAX && str[i]
			&& str[i] != '+' && str[i] != '-'
			&& !(str[i] >= 48 && str[i] <= 57))
			i++;
		while (i <= INT_MAX && str[i]
			&& (str[i] == ' ' || str[i] == '\f'
				|| str[i] == '\n' || str[i] == '\r'
				|| str[i] == '\t' || str[i] == '\v'))
			i++;
	}
	return (i);
}

int	ft_error_or_sign(unsigned int boundaries[2], const char *str)
{
	int				result;
	unsigned int	i;

	result = 0;
	boundaries[0] = -1;
	boundaries[1] = -2;
	if (str)
	{
		result = 1;
		i = ft_spaces_truncating(str);
		while (i <= INT_MAX && str[i] && (str[i] == '+' || str[i] == '-'))
		{
			if (str[i] == '-')
				result = -1 * result;
			i++;
		}
		if (i <= INT_MAX && str[i] && str[i] >= 48 && str[i] <= 57)
			boundaries[0] = (unsigned int)i;
		while (i <= INT_MAX && str[i] && str[i] >= 48 && str[i] <= 57)
			boundaries[1] = (unsigned int)i++;
		if (boundaries[0] > INT_MAX || boundaries[1] > INT_MAX
			|| boundaries[0] > boundaries[1])
				result = 0;
	}
	return (result);
}

int	ft_atoi(char *str)
{
	unsigned int	boundaries[2];
	unsigned int	i;
	int				error_or_sign;
	int				result;

	error_or_sign = ft_error_or_sign(boundaries, str);
	result = 0;
	if (error_or_sign == 0)
		return (0);
	else
	{
		i = boundaries[0];
		result = str[i++] - 48;
		while (i <= boundaries[1])
			result = (result * 10) + (str[i++] - 48);
		result *= error_or_sign;
	}
	return (result);
}
