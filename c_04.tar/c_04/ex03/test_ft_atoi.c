/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_atoi.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/20 08:52:39 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/22 13:41:19 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_atoi(char *str);

int	main(void)
{
	char	str[] = "    ---+--+1234ab567";
	char	str1[] = " cvedrf   ----+---+1234ab567";
	char	str2[] = "  sdfggf  -----+---+1234ab567";

	printf("We find the number %d into \"%s\"\n", ft_atoi(str), str);
	printf("We find the number %d into \"%s\"\n", ft_atoi(str1), str1);
	printf("We find the number %d into \"%s\"\n", ft_atoi(str2), str2);
	printf("42:%d\n", ft_atoi("  \n  42t4457"));
	printf("-42:%d\n", ft_atoi(" --+-42sfs:f545"));
	printf("0:%d\n", ft_atoi("\0 1337"));
	printf("0:%d\n", ft_atoi("-0"));
	printf("0:%d\n", ft_atoi(" - 1 3 2 5 6 3 2 1 6 7"));
	printf("-1325632167:%d\n", ft_atoi("-1325632167"));
	printf("-100:%d\n", ft_atoi("-100"));
	printf("min:%d\n", ft_atoi("\t---+2147483648"));
	printf("max:%d\n", ft_atoi("\v2147483647"));
	printf("%d\n", ft_atoi("  +3147483648"));
	return (0);
}
