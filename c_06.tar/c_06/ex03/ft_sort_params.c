/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_params.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/21 18:52:01 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/23 11:27:14 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str && str[i] != '\0')
		i++;
	return (i);
}

int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	int		result;
	int		i;
	int		j;

	result = 0;
	if (s1 && s2 && n > 0)
	{
		i = 0;
		j = 0;
		while ((s1[i] != '\0' || s2[j] != '\0')
			&& ((unsigned int) i < n || (unsigned int) j < n))
		{
			result = (unsigned char) s1[i] - (unsigned char) s2[j];
			if (result != 0)
				return (result);
			if (s1[i] != '\0')
				i++;
			if (s2[j] != '\0')
				j++;
		}
	}
	return (result);
}

void	ft_sort_params(int argc, char **argv)
{
	int		i;
	int		j;
	int		n;
	char	*temp;

	i = 1;
	while (i < argc)
	{
		j = i + 1;
		while (j < argc)
		{
			n = ft_strlen(argv[i]);
			if (n < ft_strlen(argv[j]))
				n = ft_strlen(argv[j]);
			if (ft_strncmp(argv[i], argv[j], n) > 0)
			{
				temp = argv[i];
				argv[i] = argv[j];
				argv[j] = temp;
			}
			j++;
		}
		i++;
	}
}

int	main(int argc, char **argv)
{
	int	i;

	if (argc > 1)
	{
		ft_sort_params(argc, argv);
		i = 1;
		while (i < argc)
		{
			write(1, argv[i], ft_strlen(argv[i]));
			write(1, "\n", 1);
			i++;
		}
	}
	return (0);
}
