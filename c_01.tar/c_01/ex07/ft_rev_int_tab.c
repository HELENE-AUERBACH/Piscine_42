/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/14 14:19:21 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/14 16:07:30 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_rev_int_tab(int *tab, int size)
{
	int	middle;
	int	i;
	int	temp;

	if (size > 0 && tab)
	{
		middle = size / 2;
		i = 0;
		while (i < middle)
		{
			temp = tab[i];
			tab[i] = tab[size - 1 - i];
			tab[size - 1 - i] = temp;
			i++;
		}
	}
}
