/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_sort_int_tab.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/15 07:57:08 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/15 08:24:26 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stddef.h>
#include <unistd.h>
#include <stdio.h>

void	ft_sort_int_tab(int *tab, int size);

void	ft_putnbr(int nb)
{
	long	nb_in_long;
	char	digit_to_char;

	nb_in_long = nb;
	if (nb_in_long < 0)
	{
		write(1, "-", 1);
		nb_in_long = nb_in_long * -1;
	}
	if (nb_in_long < 10)
	{
		digit_to_char = nb_in_long + '0';
		write(1, &digit_to_char, 1);
	}
	else
	{
		ft_putnbr(nb_in_long / 10);
		ft_putnbr(nb_in_long % 10);
	}
}

void	ft_print_int_tab(int *tab, int size)
{
	int	i;

	if (size >= 0 && tab)
	{
		i = 0;
		write(1, "[", 1);
		while (i < size)
		{
			if (i > 0)
				write(1, ", ", 2);
			ft_putnbr(tab[i]);
			i++;
		}
		write(1, "]", 1);
	}
	write(1, "\n", 1);
}

int	main(void)
{
	int	size;
	int	*tab1;
	int	tab2[0] = {};
	int	tab3[7] = {199, -751, 9, 1, 2, -3, 0};

	write(1, "Voici le tableau \"NULL\" trie par ordre croissant :\n", 51);
	tab1 = NULL;
	size = 0;
	ft_sort_int_tab(tab1, size);
	ft_print_int_tab(tab1, size);
	write(1, "Voici le tableau \"vide\" trie par ordre croissant :\n", 51);
	size = 0;
	ft_sort_int_tab(tab2, size);
	ft_print_int_tab(tab2, size);
	printf("Voici le tableau \"[199, -751, 9, 1, 2, -3, 0]\" trie par ordre croissant :\n");
	size = 7;
	ft_sort_int_tab(tab3, size);
	ft_print_int_tab(tab3, size);
	return (0);
}
