/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_ft_2.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/13 09:30:48 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/15 16:28:20 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>

void	ft_ft(int *nbr);

void	ft_putnbr(int nb)
{
	long	nb_in_long;
	int		digit_to_char;

	nb_in_long = nb;
	if (nb_in_long < 0)
	{
		write(1, "-", 1);
		nb_in_long = nb_in_long * -1;
	}
	if (nb_in_long < 10)
	{
		digit_to_char = nb_in_long + '0';
		write(1, &digit_to_char, 1);
	}
	else
	{
		ft_putnbr(nb_in_long / 10);
		ft_putnbr(nb_in_long % 10);
	}
}

int	main(void)
{
	int	the_number;
	int	*the_number2;

	ft_ft(&the_number);
	ft_putnbr(the_number);
	write(1, "\n", 1);
	the_number2 = (int *) malloc(sizeof(int));
	ft_ft(the_number2);
	ft_putnbr(*the_number2);
	return (0);
}
