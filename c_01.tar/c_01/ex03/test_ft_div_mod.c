/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_div_mod.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/14 09:08:23 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/14 09:34:24 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>

void	ft_div_mod(int a, int b, int *div, int *mod);

void	ft_putnbr(int nb)
{
	long	nb_in_long;
	char	digit_to_char;

	nb_in_long = nb;
	if (nb_in_long < 0)
	{
		write(1, "-", 1);
		nb_in_long = nb_in_long * -1;
	}
	if (nb_in_long < 10)
	{
		digit_to_char = nb_in_long + '0';
		write(1, &digit_to_char, 1);
	}
	else
	{
		ft_putnbr(nb_in_long / 10);
		ft_putnbr(nb_in_long % 10);
	}
}

int	main(void)
{
	int	a;
	int	b;
	int	*div;
	int	*mod;

	a = 18;
	b = 7;
	div = (int *) malloc(sizeof(int));
	*div = 0;
	mod = (int *) malloc(sizeof(int));
	*mod = 0;
	ft_div_mod(a, b, div, mod);
	write(1, "Le resultat de 18 / 7 est :\t", 28);
	ft_putnbr(*div);
	write(1, "\n", 1);
	write(1, "Le resultat de 18 % 7 est :\t", 28);
	ft_putnbr(*mod);
	write(1, "\n", 1);
	return (0);
}
