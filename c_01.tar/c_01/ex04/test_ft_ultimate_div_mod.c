/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_ultimate_div_mod.c                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/14 09:49:31 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/14 09:49:35 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>

void	ft_ultimate_div_mod(int *a, int *b);

void	ft_putnbr(int nb)
{
	long	nb_in_long;
	char	digit_to_char;

	nb_in_long = nb;
	if (nb_in_long < 0)
	{
		write(1, "-", 1);
		nb_in_long = nb_in_long * -1;
	}
	if (nb_in_long < 10)
	{
		digit_to_char = nb_in_long + '0';
		write(1, &digit_to_char, 1);
	}
	else
	{
		ft_putnbr(nb_in_long / 10);
		ft_putnbr(nb_in_long % 10);
	}
}

int	main(void)
{
	int	*a;
	int	*b;

	a = (int *) malloc(sizeof(int));
	*a = 18;
	b = (int *) malloc(sizeof(int));
	*b = 7;
	ft_ultimate_div_mod(a, b);
	write(1, "Le resultat de 18 / 7 est :\t", 28);
	ft_putnbr(*a);
	write(1, "\n", 1);
	write(1, "Le resultat de 18 % 7 est :\t", 28);
	ft_putnbr(*b);
	write(1, "\n", 1);
	return (0);
}
