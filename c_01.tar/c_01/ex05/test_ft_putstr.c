/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_putstr.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/14 12:36:00 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/14 12:55:11 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stddef.h>

void	ft_putstr(char *str);

int	main(void)
{
	ft_putstr(NULL);
	ft_putstr("La chaine qui suit est vide.\n");
	ft_putstr("");
	ft_putstr(" ~\n  !@42\\'`\";:.,/?+-()*&^%$#=[]{}\vest trop\tbIZaRRE");
	return (0);
}
