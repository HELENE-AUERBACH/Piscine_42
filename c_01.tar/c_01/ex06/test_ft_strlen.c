/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_strlen.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/14 13:30:39 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/14 13:30:43 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stddef.h>
#include <unistd.h>

int	ft_strlen(char *str);

void	ft_putnbr(int nb)
{
	long	nb_in_long;
	char	digit_to_char;

	nb_in_long = nb;
	if (nb_in_long < 0)
	{
		write(1, "-", 1);
		nb_in_long = nb_in_long * -1;
	}
	if (nb_in_long < 10)
	{
		digit_to_char = nb_in_long + '0';
		write(1, &digit_to_char, 1);
	}
	else
	{
		ft_putnbr(nb_in_long / 10);
		ft_putnbr(nb_in_long % 10);
	}
}

int	main(void)
{
	write(1, "La taille d'une chaine \"NULL\" est :\t", 36);
	ft_putnbr(ft_strlen(NULL));
	write(1, "\nLa taille d'une chaine \"vide\" est :\t", 37);
	ft_putnbr(ft_strlen(""));
	write(1, "\nLa taille de la chaine \"Piscine de fevrier 2023\" est :\t", 56);
	ft_putnbr(ft_strlen("Piscine de fevrier 2023"));
	return (0);
}
