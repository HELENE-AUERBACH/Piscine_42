/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/20 18:23:48 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/20 18:32:50 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_recursive_factorial(int nb)
{
	int	fact;

	fact = 0;
	if (nb == 0 || nb == 1)
		fact = 1;
	else if (nb > 1)
		fact = nb * ft_recursive_factorial(nb - 1);
	return (fact);
}
