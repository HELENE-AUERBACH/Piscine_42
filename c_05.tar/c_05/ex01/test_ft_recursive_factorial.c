/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_recursive_factorial.c                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/20 18:31:23 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/20 19:08:26 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_recursive_factorial(int nb);

int	main(void)
{
	printf("ft_recursive_factorial(-10) == 0:%d\n", ft_recursive_factorial(-10));
	printf("ft_recursive_factorial(-1) == 0:%d\n", ft_recursive_factorial(-1));
	printf("ft_recursive_factorial(0) == 1:%d\n", ft_recursive_factorial(0));
	printf("ft_recursive_factorial(1) == 1:%d\n", ft_recursive_factorial(1));
	printf("ft_recursive_factorial(10) == 3628800:%d\n", ft_recursive_factorial(10));
	printf("ft_recursive_factorial(3) == 6:%d\n", ft_recursive_factorial(3));
	return (0);
}
