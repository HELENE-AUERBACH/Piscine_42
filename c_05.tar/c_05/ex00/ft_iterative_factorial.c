/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/20 18:05:27 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/20 18:05:29 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_factorial(int nb)
{
	int	fact;
	int	i;

	fact = 0;
	if (nb == 0 || nb == 1)
		fact = 1;
	else if (nb > 1)
	{
		fact = 1;
		i = 2;
		while (i <= nb)
			fact *= i++;
	}
	return (fact);
}
