/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_iterative_factorial.c                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/20 18:09:42 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/20 19:06:05 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_iterative_factorial(int nb);

int	main(void)
{
	printf("ft_iterative_factorial(-10) == 0:%d\n", ft_iterative_factorial(-10));
	printf("ft_iterative_factorial(-1) == 0:%d\n", ft_iterative_factorial(-1));
	printf("ft_iterative_factorial(0) == 1:%d\n", ft_iterative_factorial(0));
	printf("ft_iterative_factorial(1) == 1:%d\n", ft_iterative_factorial(1));
	printf("ft_iterative_factorial(10) == 3628800:%d\n", ft_iterative_factorial(10));
	printf("ft_iterative_factorial(3) == 6:%d\n", ft_iterative_factorial(3));
	return (0);
}
