/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_fibonacci.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/21 08:35:03 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/21 08:35:06 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_fibonacci(int index);

int	main(void)
{
	printf("ft_fibonacci(-42) == -1:%d\n", ft_fibonacci(-42));
	printf("ft_fibonacci(0) == 0:%d\n", ft_fibonacci(0));
	printf("ft_fibonacci(1) == 1:%d\n", ft_fibonacci(1));
	printf("ft_fibonacci(2) == 1:%d\n", ft_fibonacci(2));
	printf("ft_fibonacci(3) == 2:%d\n", ft_fibonacci(3));
	printf("ft_fibonacci(10) == 55:%d\n", ft_fibonacci(10));
	return (0);
}
