/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/20 18:51:29 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/20 18:51:31 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_power(int nb, int power)
{
	int	result;
	int	i;

	result = 0;
	if (power < 0)
		result = 0;
	else if (power == 0)
		result = 1;
	else if (power == 1)
		result = nb;
	else if (nb == 0)
		result = 0;
	else if (nb == 1)
		result = 1;
	else
	{
		result = 1;
		i = 1;
		while (i <= power)
		{
			result *= nb;
			i++;
		}
	}
	return (result);
}
