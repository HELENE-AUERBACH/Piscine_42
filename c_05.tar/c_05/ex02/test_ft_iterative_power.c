/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_iterative_power.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/20 19:03:10 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/20 19:03:12 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_iterative_power(int nb, int power);

int	main(void)
{
	printf("ft_iterative_power(1, -10)) == 0:%d\n", ft_iterative_power(1, -10));
	printf("ft_iterative_power(1, -1)) == 0:%d\n", ft_iterative_power(1, -1));
	printf("ft_iterative_power(0, 0)) == 1:%d\n", ft_iterative_power(0, 0));
	printf("ft_iterative_power(10, 0)) == 1:%d\n", ft_iterative_power(10, 0));
	printf("ft_iterative_power(0, 3)) == 0:%d\n", ft_iterative_power(0, 3));
	printf("ft_iterative_power(1, 5)) == 1:%d\n", ft_iterative_power(1, 5));
	printf("ft_iterative_power(10, 1)) == 10:%d\n", ft_iterative_power(10, 1));
	printf("ft_iterative_power(10, 2)) == 100:%d\n", ft_iterative_power(10, 2));
	printf("ft_iterative_power(6, 3)) == 216:%d\n", ft_iterative_power(6, 3));
	return (0);
}
