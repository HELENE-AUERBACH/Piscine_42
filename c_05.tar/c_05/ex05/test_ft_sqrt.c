/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_sqrt.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/21 09:21:34 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/21 12:22:11 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_sqrt(int nb);

int	main(void)
{
	printf("ft_sqrt(100) == 10:%d\n", ft_sqrt(100));
	printf("ft_sqrt(36) == 6:%d\n", ft_sqrt(36));
	printf("ft_sqrt(7) == 0:%d\n", ft_sqrt(7));
	printf("ft_sqrt(10000) == 100:%d\n", ft_sqrt(10000));
	printf("ft_sqrt(101) == 0:%d\n", ft_sqrt(101));
	printf("ft_sqrt(4000000) == 2000:%d\n", ft_sqrt(4000000));
	printf("ft_sqrt(-36) == 0:%d\n", ft_sqrt(-36));
	return (0);
}
