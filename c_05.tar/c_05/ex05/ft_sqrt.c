/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/21 09:16:03 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/24 12:31:20 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <limits.h>

int	ft_sqrt(int nb)
{
	long	i;
	long	nb_into_long;

	if (nb >= 1)
	{
		i = 1;
		nb_into_long = nb;
		while (nb_into_long > i * i)
		{
			if ((i + 1) > (INT_MAX / (i + 1)))
				return (0);
			i++;
		}
		if (nb_into_long == i * i)
			return ((int) i);
	}
	return (0);
}
