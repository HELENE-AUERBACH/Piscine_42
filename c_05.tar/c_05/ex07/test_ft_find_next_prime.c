/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_find_next_prime.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/21 18:02:00 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/21 18:11:02 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_find_next_prime(int nb);

int	main(void)
{
	printf("%s : %s\n%s : %s\n%s : %s\n%s : %s\n%s : %s\n%s : %s\n%s : %s\n%s : %s\n%s : %s\n%s : %s\n%s : %s\n%s : %s\n%s : %s\n%s : %s\n%s : %s\n%s : %s\n",
		"ft_find_next_prime(-1) == 2", ft_find_next_prime(-1) == 2 ? "OK" : "Fail",
		"ft_find_next_prime(-3) == 2", ft_find_next_prime(-3) == 2 ? "OK" : "Fail",
		"ft_find_next_prime(0) == 2", ft_find_next_prime(0) == 2 ? "OK" : "Fail",
		"ft_find_next_prime(1) == 2", ft_find_next_prime(1) == 2 ? "OK" : "Fail",
		"ft_find_next_prime(2) == 2", ft_find_next_prime(2) == 2 ? "OK" : "Fail",
		"ft_find_next_prime(3) == 3", ft_find_next_prime(3) == 3 ? "OK" : "Fail",
		"ft_find_next_prime(4) == 5", ft_find_next_prime(4) == 5 ? "OK" : "Fail",
		"ft_find_next_prime(5) == 5", ft_find_next_prime(5) == 5 ? "OK" : "Fail",
		"ft_find_next_prime(6) == 7", ft_find_next_prime(6) == 7 ? "OK" : "Fail",
		"ft_find_next_prime(7) == 7", ft_find_next_prime(7) == 7 ? "OK" : "Fail",
		"ft_find_next_prime(10) == 11", ft_find_next_prime(10) == 11 ? "OK" : "Fail",
		"ft_find_next_prime(11) == 11", ft_find_next_prime(11) == 11 ? "OK" : "Fail",
		"ft_find_next_prime(13) == 13", ft_find_next_prime(13) == 13 ? "OK" : "Fail",
		"ft_find_next_prime(19) == 19", ft_find_next_prime(19) == 19 ? "OK" : "Fail",
		"ft_find_next_prime(42) == 43", ft_find_next_prime(42) == 43 ? "OK" : "Fail",
		"ft_find_next_prime(20) == 23", ft_find_next_prime(20) == 23 ? "OK" : "Fail"
		  );
	return (0);
}
