/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_find_next_prime.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/21 17:39:57 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/21 18:17:06 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_find_next_prime(int nb)
{
	int	result;
	int	i;
	int	j;

	result = 0;
	if (nb < 2)
		result = 2;
	else
	{
		result = 2;
		i = 2;
		j = nb;
		while (i < j)
		{
			while (j % i != 0)
				i++;
			if (i == j)
				result = i;
			else
				j++;
		}
	}
	return (result);
}
