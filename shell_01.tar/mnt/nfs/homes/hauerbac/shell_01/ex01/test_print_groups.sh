#!/bin/sh
export FT_USER=daemon
./print_groups.sh
