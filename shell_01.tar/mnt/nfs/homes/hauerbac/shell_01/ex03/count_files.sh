#!/bin/sh
find . -type d,f | wc -l
