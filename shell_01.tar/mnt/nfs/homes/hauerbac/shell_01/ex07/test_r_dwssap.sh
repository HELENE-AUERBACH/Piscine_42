#!/bin/sh
export FT_LINE1=7
export FT_LINE2=15
./r_dwssap.sh | cat -e
