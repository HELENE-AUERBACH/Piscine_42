#!/bin/sh
find . -name "*.sh" -ls | awk -F" " '{print $11}' | sed 's/\.sh//' | awk -F/ '{print $NF}'
