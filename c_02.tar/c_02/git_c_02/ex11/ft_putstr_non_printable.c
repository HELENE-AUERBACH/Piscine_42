/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr_non_printable.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/16 14:27:22 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/16 16:12:47 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

char	code_in_10_to_16(int value_in_10)
{
	if (value_in_10 <= 9)
		return (value_in_10 + '0');
	else
		return ((value_in_10 % 10) + 'a');
}

void	ft_putstr_non_printable(char *str)
{
	int		i;
	char	ascii_code_into_16[4];

	if (str)
	{
		i = 0;
		while (str[i] != '\0')
		{
			if (str[i] < 32 || str[i] > 126)
			{
				ascii_code_into_16[0] = '\\';
				ascii_code_into_16[1] = code_in_10_to_16(str[i] / 16);
				ascii_code_into_16[2] = code_in_10_to_16(str[i] % 16);
				ascii_code_into_16[3] = '\0';
				write(1, ascii_code_into_16, 3);
			}
			else
				write(1, &str[i], 1);
			i++;
		}
	}
}
