/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_strcapitalize.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/16 11:40:53 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/19 10:43:13 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strcapitalize(char *str);

int	main(void)
{
	char	*empty_str;
	char	str1[] = "c3PO";
	char	str1_1[] = "c3PO";
	char	str2[] = "salut, comment tu vas ? 42mots quarante-deux; cinquante+et+un";
	char	str2_1[] = "salut, comment tu vas ? 42mots quarante-deux; cinquante+et+un";
	char	str3[] = "._=e')Roaak:]Ea9";
	char	str3_1[] = "._=e')Roaak:]Ea9";
	char	str4[] = ")r/slzf@}n@*e&!e4m36@#}< w2#Hjr?`{J4";
	char	str4_1[] = ")r/slzf@}n@*e&!e4m36@#}< w2#Hjr?`{J4";
	char	str5[] = "9fi~C{!9 f7l=:H";
	char	str5_1[] = "9fi~C{!9 f7l=:H";
	char	str6[] = ")wx*{!:W3q2*}g5h6cz{+X>Y";
	char	str6_1[] = ")wx*{!:W3q2*}g5h6cz{+X>Y";
	char	str7[] = "7$$}$'2#b+V@)7j>";
	char	str7_1[] = "7$$}$'2#b+V@)7j>";
	char	str8[] = "h@t}on> yij/c)Vuztktpg}t'Zi-_Bbuna?K{wn";
	char	str8_1[] = "h@t}on> yij/c)Vuztktpg}t'Zi-_Bbuna?K{wn";
	char	str9[] = "]Y/Cbvoy;=sa,Srp6m7{4f09yhl24i+Ux.&";
	char	str9_1[] = "]Y/Cbvoy;=sa,Srp6m7{4f09yhl24i+Ux.&";
	char	str10[] = "0>5hy9'bkmya^S$1x)~K}6{";
	char	str10_1[] = "0>5hy9'bkmya^S$1x)~K}6{";
	char	str11[] = "null";
	char	str11_1[] = "null";
	char	str12[] = "Rekt17+Lol mdr Mdr 4242l42";
	char	str12_1[] = "Rekt17+Lol mdr Mdr 4242l42";

	empty_str = "";
	printf("La chaine \"vide\" donne :\n\"%s\"\n", ft_strcapitalize(empty_str));
	printf("La chaine \"%s\" donne :\n\"%s\"\n", str1_1, ft_strcapitalize(str1));
	printf("La chaine \"%s\" donne :\n\"%s\"\n", str2_1, ft_strcapitalize(str2));
	printf("La chaine \"%s\" donne :\n\"%s\"\n", str3_1, ft_strcapitalize(str3));
	printf("La chaine \"%s\" donne :\n\"%s\"\n", str4_1, ft_strcapitalize(str4));
	printf("La chaine \"%s\" donne :\n\"%s\"\n", str5_1, ft_strcapitalize(str5));
	printf("La chaine \"%s\" donne :\n\"%s\"\n", str6_1, ft_strcapitalize(str6));
	printf("La chaine \"%s\" donne :\n\"%s\"\n", str7_1, ft_strcapitalize(str7));
	printf("La chaine \"%s\" donne :\n\"%s\"\n", str8_1, ft_strcapitalize(str8));
	printf("La chaine \"%s\" donne :\n\"%s\"\n", str9_1, ft_strcapitalize(str9));
	printf("La chaine \"%s\" donne :\n\"%s\"\n", str10_1, ft_strcapitalize(str10));
	printf("La chaine \"%s\" donne :\n\"%s\"\n", str11_1, ft_strcapitalize(str11));
	printf("La chaine \"%s\" donne :\n\"%s\"\n", str12_1, ft_strcapitalize(str12));
	return (0);
}
