/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_strcapitalize_with_malloc.c                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/16 11:44:01 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/16 12:16:02 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strcapitalize_with_malloc(char *str);

int	main(void)
{
	char	*empty_str;
	char	*str1;
	char	*str2;

	empty_str = "";
	str1 = "c3PO";
	str2 = "salut, comment tu vas ? 42mots quarante-deux; cinquante+et+un";
	printf("La chaine \"vide\" donne %s\n", ft_strcapitalize_with_malloc(empty_str));
	printf("La chaine \"%s\" donne %s\n", str1, ft_strcapitalize_with_malloc(str1));
	printf("La chaine \"%s\" donne %s\n", str2, ft_strcapitalize_with_malloc(str2));
	return (0);
}
