/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/16 07:53:48 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/16 08:41:52 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_alpha(char *str)
{
	int	result;
	int	i;

	result = 1;
	if (str)
	{
		i = 0;
		while (str[i] != '\0')
		{
			if (str[i] < 'A'
				|| (str [i] > 'Z' && str[i] < 'a')
				|| str[i] > 'z')
			{
				result = 0;
				return (result);
			}
			i++;
		}
	}
	return (result);
}
