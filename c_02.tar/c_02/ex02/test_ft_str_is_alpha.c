/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_str_is_alpha.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/16 08:08:09 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/16 08:19:36 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_alpha(char *str);

int	main(void)
{
	char	*empty_str;
	char	*str1;
	char	*str2;

	empty_str = "";
	str1 = "c3po";
	str2 = "Helene";
	printf("La chaine \"vide\" donne %d\n", ft_str_is_alpha(empty_str));
	printf("La chaine \"%s\" donne %d\n", str1, ft_str_is_alpha(str1));
	printf("La chaine \"%s\" donne %d\n", str2, ft_str_is_alpha(str2));
	return (0);
}
