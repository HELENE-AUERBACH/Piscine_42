/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_str_is_uppercase.c                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/16 09:15:20 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/16 09:15:23 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_uppercase(char *str);

int	main(void)
{
	char	*empty_str;
	char	*str1;
	char	*str2;

	empty_str = "";
	str1 = "C3po";
	str2 = "HELENE";
	printf("La chaine \"vide\" donne %d\n", ft_str_is_uppercase(empty_str));
	printf("La chaine \"%s\" donne %d\n", str1, ft_str_is_uppercase(str1));
	printf("La chaine \"%s\" donne %d\n", str2, ft_str_is_uppercase(str2));
	return (0);
}
