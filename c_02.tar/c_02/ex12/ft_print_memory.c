/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_memory.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/16 19:24:18 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/16 20:07:22 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

char	code_in_10_to_16(int value_in_10)
{
	if (value_in_10 <= 9)
		return (value_in_10 + '0');
	else
		return ((value_in_10 % 10) + 'a');
}

unsigned int	ft_strlcpy(char *dest, char *src, unsigned int size)
{
	unsigned int	i;

	if (src && dest && size > 0)
	{
		i = 0;
		while (i < size && src[i] != '\0')
		{
			dest[i] = src[i];
			i++;
		}
		dest[i] = '\0';
		return (i);
	}
	return (-1);
}

void	*ft_print_memory(void *addr, unsigned int size)
{
	int		i;
	int		j;
	int		k;
	char	*str;
	char	ascii_code_into_16[4];
	char	dest[76];

	if (addr && size > 0)
	{
		str = (char *) addr;
		i = 0;
		while (i < size)
		{
			ft_strlcpy(dest, &str[i], 17);
			dest[17] = ':';
			dest[18] = ' ';
			while (i < size && str[i] != '\0')
			{
				j = 0;
				k = 0;
				while (j < 16 && i < size && str[i] != '\0')
				{
					if (str[i] < 32 || str[i] > 126)
						dest[59 + k] = '.';
					else
						dest[59 + k] = str[i];
					k++;
					ascii_code_into_16[0] = code_in_10_to_16(str[i] / 16);
					ascii_code_into_16[1] = code_in_10_to_16(str[i] % 16);
					ascii_code_into_16[2] = '\0';
					ft_strlcpy(dest + 19 + j, ascii_code_into_16, 3);
					if (i % 2 != 0)
						dest[19 + j + 3] = ' ';
					i++;
					j++;
				}
				if (j < 16)
					i = size;
				while (j < 16)
				{
					dest[19 + j] = ' ';
					j++;
					if (j % 2 != 0)
						dest[19 + j] = ' ';
				}
				if (i % 16 != 0)
					dest[19 + j] = ' ';
				dest[75] = '\n';
				dest[76] = '\0';
				write(1, dest, 76);
			}
		}
	}

	return (addr);
}
