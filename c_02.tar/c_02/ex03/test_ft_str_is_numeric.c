/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_str_is_numeric.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/16 08:53:34 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/16 08:53:36 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_numeric(char *str);

int	main(void)
{
	char	*empty_str;
	char	*str1;
	char	*str2;

	empty_str = "";
	str1 = "C3po";
	str2 = "1234567890";
	printf("La chaine \"vide\" donne %d\n", ft_str_is_numeric(empty_str));
	printf("La chaine \"%s\" donne %d\n", str1, ft_str_is_numeric(str1));
	printf("La chaine \"%s\" donne %d\n", str2, ft_str_is_numeric(str2));
	return (0);
}
