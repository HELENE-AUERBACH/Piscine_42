/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/16 08:26:05 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/16 08:50:50 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_numeric(char *str)
{
	int	result;
	int	i;

	result = 1;
	if (str)
	{
		i = 0;
		while (str[i] != '\0')
		{
			if (str[i] < 48 || str[i] > 57)
			{
				result = 0;
				return (result);
			}
			i++;
		}
	}
	return (result);
}
