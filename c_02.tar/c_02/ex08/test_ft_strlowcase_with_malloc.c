/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_strlowcase_with_malloc.c                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/16 11:17:23 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/16 11:17:38 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strlowcase_with_malloc(char *str);

int	main(void)
{
	char	*empty_str;
	char	*str1;
	char	*str2;

	empty_str = "";
	str1 = "C3Po";
	str2 = "HELeNE";
	printf("La chaine \"vide\" donne %s\n", ft_strlowcase_with_malloc(empty_str));
	printf("La chaine \"%s\" donne %s\n", str1, ft_strlowcase_with_malloc(str1));
	printf("La chaine \"%s\" donne %s\n", str2, ft_strlowcase_with_malloc(str2));
	return (0);
}
