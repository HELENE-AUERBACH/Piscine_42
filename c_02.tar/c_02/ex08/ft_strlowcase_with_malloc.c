/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlowcase_with_malloc.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/16 11:15:11 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/16 11:15:14 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

char	*ft_strlowcase_with_malloc(char *str)
{
	int		i;
	int		size;
	char	*result_str;

	if (str)
	{
		i = 0;
		while (str[i] != '\0')
			i++;
		size = i;
		result_str = (char *) malloc(size * sizeof(char));
		i = 0;
		while (i < size)
		{
			if (str[i] >= 'A' && str[i] <= 'Z')
				result_str[i] = str[i] + 32;
			else
				result_str[i] = str[i];
			i++;
		}
		result_str[i] = '\0';
		str = result_str;
	}
	return (str);
}
