/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_strlowcase.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/16 11:17:58 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/16 11:24:14 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strlowcase(char *str);

int	main(void)
{
	char	*empty_str;
	char	str1[] = "C3Po";
	char	str1_1[] = "C3Po";
	char	str2[] = "HELeNE";
	char	str2_1[] = "HELeNE";

	empty_str = "";
	printf("La chaine \"vide\" donne %s\n", ft_strlowcase(empty_str));
	printf("La chaine \"%s\" donne %s\n", str1_1, ft_strlowcase(str1));
	printf("La chaine \"%s\" donne %s\n", str2_1, ft_strlowcase(str2));
	return (0);
}
