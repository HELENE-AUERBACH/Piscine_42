/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_strlcpy.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/16 13:30:21 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/19 13:44:35 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
 * La fonction ﻿strlcpy permet de copier une chaîne de caractères dans une autre chaîne en limitant le nombre de caractères copiés.
 * Pour utiliser la fonction strlcpy , il faut inclure la bibliothèque bsd/string.h
 * Notez enfin que pour utiliser cette bibliothèque, vous devez ajouter l'option -lbsd à la compilation :
 * gcc -o main main.c -lbsd
 * Notez que la fonction strlcpy n'appartient pas au C standard, alors que strncpy appartient à string.h.
 */

#include <stdio.h>
#include <bsd/string.h>

unsigned int	ft_strlcpy(char *dest, char *src, unsigned int size);

int	main(void)
{
	unsigned int	n;
	char			dest1_0[25];
	char			dest1[25];
	char			dest1_1[25];
	unsigned int	result_1;
	char			*src1;
	char			*src2;
	char			dest2_0[5] = "M";
	char			dest2[5] = "M";
	char			dest2_1[5] = "M";
	unsigned int	result_2;

	src1 = "Toto Titi";
	n = 10;
	result_1 = ft_strlcpy(dest1, src1, n);
	printf("Voici la chaine \"%s\" copiee dans la chaine \"%s\" : \"%s\"\n", src1, dest1_0, dest1);
	printf("%d (avec strlcpy et n == %d : %ld) se termine par '%c' (%d)\n", result_1, n, strlcpy(dest1_1, src1, n), dest1[n -1], dest1[n -1]);
	src2 = "Tuut";
	n = 5;
	result_2 = ft_strlcpy(dest2, src2, n);
	printf("Voici la chaine \"%s\" copiee dans la chaine \"%s\" : \"%s\"\n", src2, dest2_0, dest2);
	printf("%d (avec strlcpy et n == %d : %ld) se termine par '%c' (%d)\n", result_2, n, strlcpy(dest2_1, src2, n), dest2[n -1], dest2[n -1]);
	
	char src1a[] = "abcde";
	char dest1a[] = "1234567";
	char src1b[] = "abcde";
	char dest1b[] = "1234567";
	char src2a[] = "abcd";
	char dest2a[] = "123";
	char src2b[] = "abcd";
	char dest2b[] = "123";
	char src3a[] = "";
	char dest3a[] = "";
	char src3b[] = "";
	char dest3b[] = "";
	char src4a[] = "12345";
	char dest4a[] = "abc";
	char src4b[] = "12345";
	char dest4b[] = "abc";
	
	printf("%s\n%s\n%d %ld %d\n\"%s\"\n\"%s\"\n%s\n%s\n%d %ld %d\n\"%s\"\n\"%s\"\n%s\n%s\n%d %ld %d\n\"%s\"\n\"%s\"\n%s\n%s\n%d %ld %d\n\"%s\"\n\"%s\"\n",
			"abcde", "1234567", 0, strlcpy(dest1b, src1b, 0), ft_strlcpy(dest1a, src1a, 0), dest1b, dest1a,
			"abcd", "123", 3, strlcpy(dest2a, src2a, 3), ft_strlcpy(dest2b, src2b, 3), dest2a, dest2b,
			"", "", 0, strlcpy(dest3a, src3a, 0), ft_strlcpy(dest3b, src3b, 0), dest3a, dest3b,
			"12345", "abc", 2, strlcpy(dest4a, src4a, 2), ft_strlcpy(dest4b, src4b, 2), dest4a, dest4b);
	/*printf("%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n",
			ft_strlcpy(dest1a, src1a, 0) == strlcpy(dest1b, src1b, 0) ? "Pass" : "Fail",
			strcmp(dest1a, dest1b) == 0 && strcmp(src1a, src1b) == 0 ? "Pass" : "Fail",
			ft_strlcpy(dest2a, src2a, 3) == strlcpy(dest2b, src2b, 3) ? "Pass" : "Fail",
			strcmp(dest2a, dest2b) == 0 && strcmp(src2a, src2b) == 0 ? "Pass" : "Fail",
			ft_strlcpy(dest3a, src3a, 0) == strlcpy(dest3b, src3b, 0) ? "Pass" : "Fail",
			strcmp(dest3a, dest3b) == 0 && strcmp(src3a, src3b) == 0 ? "Pass" : "Fail",
			ft_strlcpy(dest4a, src4a, 2) == strlcpy(dest4b, src4b, 2) ? "Pass" : "Fail",
			strcmp(dest4a, dest4b) == 0 && strcmp(src4a, src4b) == 0 ? "Pass" : "Fail");*/
	return (0);
}
