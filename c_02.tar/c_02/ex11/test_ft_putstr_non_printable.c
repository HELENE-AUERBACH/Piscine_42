/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_putstr_non_printable.c                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/16 15:08:08 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/19 15:20:30 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_putstr_non_printable(char *str);

int	main(void)
{
	char	*empty_str;
	char	*str1;
	char	*str2;
	char	*str3;

	empty_str = "";
	printf("La chaine \"vide\" donne :\n");
	ft_putstr_non_printable(empty_str);
	printf("\n");
	str1 = "Tab\tLF\nVT\vUS\037Not complete list";
	printf("La chaine \"%s\" donne :\n", str1);
	ft_putstr_non_printable(str1);
	printf("\n");
	str2 = "1 !\"#$%&'()*+,-./023456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~";
	printf("La chaine \"%s\" donne :\n", str2);
	ft_putstr_non_printable(str2);
	printf("\n");
	str3 = "Coucou\ntu vas bien ?";
	printf("La chaine \"%s\" donne :\n", str3);
	ft_putstr_non_printable(str3);
	printf("\n");

	char d[] = "\x81\xbe";
	printf("La chaine \"%s\" donne :\n", "\x81\xbe");
	ft_putstr_non_printable(d);
	printf("\n");
	return (0);
}
