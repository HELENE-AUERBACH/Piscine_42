/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_strupcase.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/16 10:03:44 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/16 11:28:07 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strupcase(char *str);

int	main(void)
{
	char	*empty_str;
	char	str1[] = "c3pO";
	char	str1_1[] = "c3pO";
	char	str2[] = "hElene";
	char	str2_1[] = "hElene";

	empty_str = "";
	printf("La chaine \"vide\" donne %s\n", ft_strupcase(empty_str));
	printf("La chaine \"%s\" donne %s\n", str1_1, ft_strupcase(str1));
	printf("La chaine \"%s\" donne %s\n", str2_1, ft_strupcase(str2));
	return (0);
}
