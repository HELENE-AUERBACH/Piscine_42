/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strupcase_with_malloc.c                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/16 10:44:59 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/16 10:54:07 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

char	*ft_strupcase_with_malloc(char *str)
{
	int		i;
	int		size;
	char	*result_str;

	if (str)
	{
		i = 0;
		while (str[i] != '\0')
			i++;
		size = i;
		result_str = (char *) malloc(size * sizeof(char));
		i = 0;
		while (i < size)
		{
			if (str[i] >= 'a' && str[i] <= 'z')
				result_str[i] = str[i] - 32;
			else
				result_str[i] = str[i];
			i++;
		}
		result_str[i] = '\0';
		str = result_str;
	}
	return (str);
}
