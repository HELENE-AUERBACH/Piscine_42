/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_strupcase_with_malloc.c                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/16 10:52:27 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/16 10:52:39 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strupcase_with_malloc(char *str);

int	main(void)
{
	char	*empty_str;
	char	*str1;
	char	*str2;

	empty_str = "";
	str1 = "c3pO";
	str2 = "hElene";
	printf("La chaine \"vide\" donne %s\n", ft_strupcase_with_malloc(empty_str));
	printf("La chaine \"%s\" donne %s\n", str1, ft_strupcase_with_malloc(str1));
	printf("La chaine \"%s\" donne %s\n", str2, ft_strupcase_with_malloc(str2));
	return (0);
}
