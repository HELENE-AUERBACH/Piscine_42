#include <stdio.h>
#include <string.h>

int	main(void)
{
	char	dest1[10] = "123456789";
	char	dest1_1[10] = "123456789";
	char	src2[] = "Tuut";
	char	dest2[2] = "H";
	char	dest2_1[2] = "H";

	printf("Voici la chaine \"%s\" copiee dans la chaine \"%s\" :\n", src2, dest1);
	printf("%s\n", strcpy(dest1_1, src2));
	printf("Voici la chaine \"%s\" copiee dans la chaine \"%s\" :\n", src2, dest2);
	printf("%s\n", strcpy(dest2_1, src2));
	return (0);
}
