/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_strcpy.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/15 10:13:49 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/15 10:53:05 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stddef.h>
#include <stdio.h>
#include <string.h>

char	*ft_strcpy(char *dest, char *src);

int	main(void)
{
	//char	*null_dest;
	//char	*null_src;
	//char	*empty_dest;
	char	*empty_src;
	char	dest1[25];
	char	dest1_1[25];
	//char	*src1;
	char	*src2;
	char	dest2[2];
	char	dest2_1[2];

	//null_src = NULL;
	//null_dest = NULL;
	empty_src = "";
	//empty_dest = "";
	//src1 = "Toto Titi";
	src2 = "Tuut";
	/*printf("Voici la chaine \"NULL\" copiee dans une autre chaine \"NULL\" :\n");
	printf("%s\n", ft_strcpy(null_dest, null_src));*/
	/*printf("Voici la chaine \"vide\" copiee dans une autre chaine \"NULL\" :\n");
	printf("%s\n", ft_strcpy(null_dest, empty_src));*/
	printf("Voici la chaine \"vide\" copiee dans une autre chaine \"%s\" :\n", dest1);
	printf("%s (avec strcpy : %s)\n", ft_strcpy(dest1, empty_src), strcpy(dest1, empty_src));
	/*printf("Voici la chaine \"%s\" copiee dans une autre chaine \"vide\" :\n", src1);
	printf("%s\n", ft_strcpy(empty_dest, src1));*/
	printf("Voici la chaine \"%s\" copiee dans la chaine \"%s\" :\n", src2, dest1);
	printf("%s (avec strcpy : %s)\n", ft_strcpy(dest1, src2), strcpy(dest1_1, src2));
	printf("Voici la chaine \"%s\" copiee dans la chaine \"%s\" :\n", src2, dest2);
	printf("%s (avec strcpy : %s)\n", ft_strcpy(dest2, src2), strcpy(dest2_1, src2));
	return (0);
}
