/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_str_is_printable.c                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/16 09:36:35 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/16 09:37:08 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_printable(char *str);

int	main(void)
{
	char	*empty_str;
	char	*str1;
	char	*str2;

	empty_str = "";
	str1 = "Tab\tLF\nVT\vNot complete list";
	str2 = "1 !\"#$%&'()*+,-./023456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~";
	printf("La chaine \"vide\" donne %d\n", ft_str_is_printable(empty_str));
	printf("La chaine \"%s\" donne %d\n", str1, ft_str_is_printable(str1));
	printf("La chaine \"%s\" donne %d\n", str2, ft_str_is_printable(str2));
	return (0);
}
