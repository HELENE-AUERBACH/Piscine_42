/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/16 09:27:39 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/16 09:27:42 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_printable(char *str)
{
	int	result;
	int	i;

	result = 1;
	if (str)
	{
		i = 0;
		while (str[i] != '\0')
		{
			if (str[i] < 32 || str[i] > 126)
			{
				result = 0;
				return (result);
			}
			i++;
		}
	}
	return (result);
}
