/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_strncpy.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/15 14:41:31 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/15 18:54:17 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
 *  Cette fonction permet de copier le contenu d'une chaîne de caractère dans une autre, dans la limite de n caractères. Plusieurs cas peuvent être considérés :

    Si la chaîne source a une taille inférieure à celle spécifiée en paramètre (paramètre n), alors la chaîne de destination sera complétée avec des codes ASCII nuls (caractère '\0').
    Si la chaîne source a une taille supérieure à celle spécifiée en paramètre, alors la chaîne produite ne sera pas terminée par un code ASCII nul (caractère '\0'). Il sera alors de votre responsabilité de l'ajouter si vous souhaitez exploiter correctement la chaîne produite. En effet, n'oubliez pas qu'en C on manipule des chaînes AZT (A Zéro Terminal).
    Si la chaîne source a une taille égale à celle spécifiée en paramètre, alors la chaîne source sera intégralement copiée (y compris le code ASCII 0 terminal).

Rappel : en langage C, les chaînes de caractères sont qualifiées d'AZT : A Zéro Terminal. Cela signifie qu'une chaîne de caractères se termine forcément par un code ASCII nul (pouvant aussi être représenté par '\0'). 
 */
#include <stddef.h>
#include <stdio.h>
#include <string.h>

char	*ft_strncpy(char *dest, char *src, unsigned int n);

int	main(void)
{
	unsigned int	n;
	char			*empty_src;
	//char			*null_dest;
	//char			*null_dest_1;
	char			dest0[25];
	char			dest0_1[25];
	char			dest1[25];
	char			dest1_1[25];
	char			*src1;
	char			*src2;
	char			dest2[5] = "M";
	char			dest2_1[5] = "M";

	empty_src = "";
	n = 2;
	printf("Voici la chaine \"vide\" copiee dans une autre chaine \"%s\" :\n", dest0);
	printf("%s (avec strncpy et n == %d : %s) se termine par '%c' (%d)\n", ft_strncpy(dest0, empty_src, n), n, strncpy(dest0_1, empty_src, n), dest0[n -1], dest0[n -1]);
	//printf("Voici la chaine \"vide\" copiee dans une autre chaine \"%s\" :\n", null_dest);
	//printf("%s (avec strncpy et n == %d : %s) se termine par '%c' (%d)\n", ft_strncpy(null_dest, empty_src, n), n, strncpy(null_dest_1, empty_src, n), null_dest[n -1], null_dest[n -1]);
	src1 = "Toto Titi";
	n = 7;
	printf("Voici la chaine \"%s\" copiee dans la chaine \"%s\" :\n", src1, dest1);
	printf("%s (avec strncpy et n == %d : %s) se termine par '%c' (%d)\n", ft_strncpy(dest1, src1, n), n, strncpy(dest1_1, src1, n), dest1[n -1], dest1[n -1]);
	src2 = "Tuut";
	n = 4;
	printf("Voici la chaine \"%s\" copiee dans la chaine \"%s\" :\n", src2, dest2);
	printf("%s (avec strncpy et n == %d : %s) se termine par '%c' (%d)\n", ft_strncpy(dest2, src2, n), n, strncpy(dest2_1, src2, n), dest2[n -1], dest2[n -1]);
	return (0);
}
