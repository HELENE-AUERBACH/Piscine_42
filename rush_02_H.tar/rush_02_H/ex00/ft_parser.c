/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parser.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: octoross <octoross@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/25 16:18:47 by soutin            #+#    #+#             */
/*   Updated: 2023/02/26 17:20:56 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_library.h"

t_dict	*ft_parser(char *dict_name, int *win);

int	ft_check_format(char *entry)
{
	int	i;

	i = 0;
	while (entry[i] == ' ')
		i++;
	if (entry[i] == '+')
		i++;
	if ('0' > entry[i] || entry[i] > '9')
		return (0);
	i++;
	while ('0' <= entry[i] && entry[i] <= '9')
		i++;
	while (entry[i] == ' ')
		i++;
	if (entry[i] != ':')
		return (0);
	i++;
	while (entry[i] == ' ')
		i++;
	while (entry[i] != '\0')
		if (!ft_char_is_printable(entry[i++]))
			return (0);
	return (1);
}

char	*ft_strcat(char *dest, char *src)
{
	int		i;
	int		j;

	if (dest && src)
	{
		i = 0;
		while (dest[i] != '\0')
			i++;
		j = 0;
		while (src[j] != '\0')
		{
			dest[i] = src[j];
			i++;
			j++;
		}
		dest[i] = '\0';
	}
	return (dest);
}

char	*ft_trunc_multiple_spaces(char *str)
{
	char	**words;
	int		count;
	char	*ptr;
	int		i;

	words = ft_split(str, " ");
	count = ft_strtablen(words);
	ptr = NULL;
	if (count > 0)
	{
		ptr = (char *) malloc((ft_strlen(str) + 1) * sizeof(char));
		if (!ptr)
			return (NULL);
		ft_strcat(ptr, words[0]);
		i = 1;
		while (i < count)
		{
			if ((words[i][0] != ':')
				&& (words[i - 1][ft_strlen(words[i - 1]) - 1] != ':'))
				ft_strcat(ptr, " ");
			ft_strcat(ptr, words[i]);
			i++;
		}
	}
	return (ptr);
}

int	ft_check_and_dict(char **entries, t_dict *dicts)
{
	int		i;
	char	*line;
	char	**entry;

	i = 0;
	while (entries[i])
	{
		if (!ft_check_format(entries[i]))
			return (0);
		line = ft_trunc_multiple_spaces(entries[i]);
		if (!line)
			return (0);
		entry = ft_split(line, ":");
		free(line);
		if ((ft_strtablen(entry) != 2)
			|| (ft_atoi_dict(entry[0]) == -1)
			|| (!ft_is_printable(entry[1])))
			return (0);
		dicts[i].key = ft_atoi_dict(entry[0]);
		dicts[i].value = entry[1];
		i++;
	}
	dicts[i].key = -1;
	dicts[i].value = "";
	return (1);
}

t_dict	*ft_parser(char *dict_name, int *win)
{
	int		fd;
	int		nb_bytes;
	char	buffer[BUFF_SIZE + 1];
	char	**entries;
	t_dict	*dicts;

	fd = open(dict_name, O_RDONLY);
	if (fd == -1)
		return (0);
	nb_bytes = read(fd, buffer, BUFF_SIZE);
	if (close(fd) == -1)
		return (0);
	buffer[nb_bytes] = '\0';
	entries = ft_split(buffer, "\n");
	dicts = (t_dict *)malloc(sizeof(t_dict) * (ft_strtablen(entries) + 1));
	if (!dicts)
		*win = 0;
	*win = ft_check_and_dict(entries, dicts);
	return (dicts);
}
