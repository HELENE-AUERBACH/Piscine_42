/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_dict_manip.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: soutin <soutin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/25 19:08:15 by soutin            #+#    #+#             */
/*   Updated: 2023/02/25 20:05:01 by soutin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_library.h"

char			*ft_value_of_key(unsigned int key, t_dict *dicts);
unsigned int	ft_max(unsigned int n, t_dict *dicts);

unsigned int	ft_max(unsigned int n, t_dict *dicts)
{
	int				i;
	unsigned int	max;

	i = 0;
	max = 0;
	while (dicts[i].key >= 0)
	{
		if ((unsigned int)dicts[i].key > max && (unsigned int)dicts[i].key <= n)
			max = (unsigned int)dicts[i].key;
		i++;
	}
	return (max);
}

char	*ft_value_of_key(unsigned int key, t_dict *dicts)
{
	int	i;

	i = 0;
	while (dicts[i].key >= 0 && (unsigned int)dicts[i].key != key)
		i++;
	if (dicts[i].key == -1)
		return ("");
	return (dicts[i].value);
}
