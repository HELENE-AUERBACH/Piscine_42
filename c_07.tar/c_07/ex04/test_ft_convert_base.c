/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_convert_base.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/01 14:53:06 by hauerbac          #+#    #+#             */
/*   Updated: 2023/03/01 17:28:21 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_convert_base(char *nbr, char *base_from, char *base_to);

int	main(void)
{
	printf("42 en base 10: %s", ft_convert_base("42", "0123456789", "0123456789"));
	printf("\n2a == 42 en base 16: %s", ft_convert_base("2a", "0123456789abcdef", "0123456789"));
	printf("\n-2a == -42 en base 16: %s", ft_convert_base("-2a", "0123456789abcdef", "0123456789"));
	printf("\n (42 en base vide): %s", ft_convert_base("42", "0123456789", ""));
	printf("\n (42 en base de taille 1): %s", ft_convert_base("42", "0", "0123456789"));
	printf("\n (42 en base 16 avec + et -): %s", ft_convert_base("42", "0123456789", "+-0123456789abcdef"));
	printf("\n (42 en base 16 avec une tabulation): %s", ft_convert_base("42", "0123456789", "\t0123456789abcdef"));
	printf("\n101010 == 42 en base 2: %s", ft_convert_base("42", "0123456789", "01"));
	printf("\nvn == 42 en base 8 (\"poneyvif\"): %s", ft_convert_base("vn", "poneyvif", "0123456789"));
}
