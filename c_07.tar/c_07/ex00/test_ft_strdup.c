/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_strdup.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/22 16:07:32 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/24 10:21:37 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

char	*ft_strdup(char *src);

int	main(void)
{
	char	*duplicated;

	duplicated = ft_strdup("Toto");
	printf("\"%s\" duplicated : \"%s\"\n", "Toto", duplicated);
	free(duplicated);
	duplicated = ft_strdup("");
	printf("\"%s\" duplicated : \"%s\"\n", "", duplicated);
	free(duplicated);
	duplicated = ft_strdup("1");
	printf("\"%s\" duplicated : \"%s\"\n", "1", duplicated);
	free(duplicated);
	return (0);
}
