git log --pretty=format:"%H" -5
