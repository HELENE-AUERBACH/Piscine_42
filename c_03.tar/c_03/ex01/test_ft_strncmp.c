/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_strncmp.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/17 08:49:35 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/17 08:49:39 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_strncmp(char *s1, char *s2, unsigned int n);

int	main(void)
{
	char	s1_1[] = "ABC";
	char	s2_1[] = "ABC";
	char	s1_2[] = "ABC";
	char	s2_2[] = "AB";
	char	s1_3[] = "ABC";
	char	s2_3[] = "AB";
	char	s1_4[] = "ABC";
	char	s2_4[] = "ABC";
	char	s1_5[] = "\201";
	char	s2_5[] = "A";

	printf("%s compare a %s pour n = %d donne %d\n", s1_1, s2_1, 5, ft_strncmp(s1_1, s2_1, 5));
	printf("%s compare a %s pour n = %d donne %d\n", s1_2, s2_2, 3, ft_strncmp(s1_2, s2_2, 3));
	printf("%s compare a %s pour n = %d donne %d\n", s1_3, s2_3, 2, ft_strncmp(s1_3, s2_3, 2));
	printf("%s compare a %s pour n = %d donne %d\n", s1_4, s2_4, 3, ft_strncmp(s1_4, s2_4, 3));
	printf("%s compare a %s pour n = %d donne %d\n", s1_5, s2_5, 1, ft_strncmp(s1_5, s2_5, 1));
	return (0);
}
