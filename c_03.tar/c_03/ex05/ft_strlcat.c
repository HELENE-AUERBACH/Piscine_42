/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/17 11:11:29 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/22 12:41:30 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str && str[i] != '\0')
		i++;
	return (i);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	int				i;
	int				j;
	unsigned int	dest_len;
	unsigned int	src_len;

	dest_len = (unsigned int) ft_strlen(dest);
	src_len = (unsigned int) ft_strlen(src);
	if (dest_len >= size)
		return (size + src_len);
	if (size > 0)
	{
		i = dest_len;
		j = 0;
		while ((unsigned int) j < size - 1 - dest_len && src[j] != '\0')
		{
			dest[i] = src[j];
			i++;
			j++;
		}
		dest[i] = '\0';
		return (dest_len + src_len);
	}
	return (src_len);
}
