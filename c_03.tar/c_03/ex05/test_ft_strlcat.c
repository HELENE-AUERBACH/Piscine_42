/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_strlcat.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/17 11:30:51 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/22 12:26:06 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <bsd/string.h>

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size);

int	main(void)
{
	char	*src1 = "defghijklmnopq";
	char	dest1[5];
	char	*src2 = "defgh";
	char	dest2[5];
	char	*src3 = "";
	char	dest3[5];
	char	*src4 = "abcd";
	char	dest4[5];

	/* avec strlcpy et strlcat, on peut balancer tout ce
	 * qu\'on veut dans le tableau, on sait qu'on ne déborde pas.
	 * C'est ça qui est bien.
	*/
	printf("\"%s\" concatene a \"%s\" pour n = %ld donne :\n", src1, dest1, sizeof(dest1));
	printf("%d (\"%s\")\n", ft_strlcat(dest1, src1, (unsigned int) sizeof(dest1)), dest1);
	printf("\"%s\" concatene a \"%s\" pour n = %d donne :\n", src2, dest2, 5);
	printf("%d (\"%s\")\n", ft_strlcat(dest2, src2, 5), dest2);
	printf("\"%s\" concatene a \"%s\" pour n = %d donne :\n", src3, dest3, 1);
	printf("%d (\"%s\")\n", ft_strlcat(dest3, src3, 1), dest3);
	printf("\"%s\" concatene a \"%s\" pour n = %d donne :\n", src4, dest4, 9);
	printf("%d (\"%s\")\n", ft_strlcat(dest4, src4, 9), dest4);

	char s1a[10] = "Test1";
	char s2a[] = "OK";
	char s1b[10] = "Test1";
	char s2b[] = "OK";
	char s3a[10] = "Same";
	char s4a[] = "Size";
	char s3b[10] = "Same";
	char s4b[] = "Size";
	char s5a[20] = "Shorter";
	char s6a[] = "ThanMyself";
	char s5b[20] = "Shorter";
	char s6b[] = "ThanMyself";
	char s7a[20] = "Shorter";
	char s8a[] = "ThanMyself";
	char s7b[20] = "Shorter";
	char s8b[] = "ThanMyself";

	printf("%s\n", ft_strlcat(s1a, s2a, 6) == strlcat(s1b, s2b, 6) ? "Success" : "Fail");
	printf("%s\n", strcmp(s1a, s1b) == 0 && strcmp(s2a, s2b) == 0 ? "Success" : "Fail");
	printf("%s\n", ft_strlcat(s3a, s4a, 10) == strlcat(s3b, s4b, 10) ? "Success" : "Fail");
	printf("%s\n", strcmp(s3a, s3b) == 0 && strcmp(s4a, s4b) == 0 ? "Success" : "Fail");
	printf("%s\n", ft_strlcat(s5a, s6a, 4) == strlcat(s5b, s6b, 4) ? "Success" : "Fail");
	printf("%s\n", strcmp(s5a, s5b) == 0 && strcmp(s6a, s6b) == 0 ? "Success" : "Fail");
	printf("%s\n", ft_strlcat(s7a, s8a, 0) == strlcat(s7b, s8b, 0) ? "Success" : "Fail");
	printf("%s\n", strcmp(s7a, s7b) == 0 && strcmp(s8a, s8b) == 0 ? "Success" : "Fail");
	
	printf("\n\nDetails:\n");
	printf("%s:%s\n%s:%s\n", s1a, s1b, s2a, s2b);
	printf("%s:%s\n%s:%s\n", s3a, s3b, s4a, s4b);
	printf("%s:%s\n%s:%s\n", s5a, s5b, s6a, s6b);
	printf("%s:%s\n%s:%s\n", s7a, s7b, s8a, s8b);
	return (0);
}
