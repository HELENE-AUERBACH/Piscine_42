/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/17 08:06:45 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/17 08:24:02 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strcmp(char *s1, char *s2)
{
	int		result;
	int		i;
	int		j;

	result = 0;
	if (s1 && s2)
	{
		i = 0;
		j = 0;
		while (s1[i] != '\0' || s2[j] != '\0')
		{
			result = (unsigned char) s1[i] - (unsigned char) s2[j];
			if (result != 0)
				return (result);
			if (s1[i] != '\0')
				i++;
			if (s2[j] != '\0')
				j++;
		}
	}
	return (result);
}
