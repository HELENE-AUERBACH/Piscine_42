/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_strcmp.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/17 08:18:43 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/17 08:26:34 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_strcmp(char *s1, char *s2);

int	main(void)
{
	char	s1_1[] = "ABC";
	char	s2_1[] = "ABC";
	char	s1_2[] = "ABC";
	char	s2_2[] = "AB";
	char	s1_3[] = "ABA";
	char	s2_3[] = "ABZ";
	char	s1_4[] = "ABJ";
	char	s2_4[] = "ABC";
	char	s1_5[] = "\201";
	char	s2_5[] = "A";

	printf("%s compare a %s donne %d\n", s1_1, s2_1, ft_strcmp(s1_1, s2_1));
	printf("%s compare a %s donne %d\n", s1_2, s2_2, ft_strcmp(s1_2, s2_2));
	printf("%s compare a %s donne %d\n", s1_3, s2_3, ft_strcmp(s1_3, s2_3));
	printf("%s compare a %s donne %d\n", s1_4, s2_4, ft_strcmp(s1_4, s2_4));
	printf("%s compare a %s donne %d\n", s1_5, s2_5, ft_strcmp(s1_5, s2_5));
	return (0);
}
