/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/17 10:21:08 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/17 10:43:11 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stddef.h>

int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	int		result;
	int		i;
	int		j;

	result = 0;
	if (s1 && s2 && n > 0)
	{
		i = 0;
		j = 0;
		while ((s1[i] != '\0' || s2[j] != '\0')
			&& ((unsigned int) i < n || (unsigned int) j < n))
		{
			result = (unsigned char) s1[i] - (unsigned char) s2[j];
			if (result != 0)
				return (result);
			if (s1[i] != '\0')
				i++;
			if (s2[j] != '\0')
				j++;
		}
	}
	return (result);
}

char	*ft_strstr(char *str, char *to_find)
{
	int	i;
	int	size;

	if (str && to_find)
	{
		i = 0;
		while (to_find[i] != '\0')
			i++;
		size = i;
		if (size == 0)
			return (str);
		else
		{
			i = 0;
			while (str[i] != '\0' && ft_strncmp(&str[i], to_find, size) != 0)
				i++;
			if (str[i] != '\0')
				return (&str[i]);
		}
	}
	return (NULL);
}
