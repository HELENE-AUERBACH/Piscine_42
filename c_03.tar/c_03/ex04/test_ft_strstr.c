/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_strstr.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/17 10:40:29 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/18 13:46:53 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

char	*ft_strstr(char *str, char *to_find);

int	main(void)
{
	char	src1[] = "";
	char	to_find1[] = "";
	char	src2[] = "ABC";
	char	to_find2[] = "";
	char	src3[] = "Toto Tata";
	char	to_find3[] = "Toto";
	char	src4[] = "Tuto Tata";
	char	to_find4[] = " Ta";
	char	src5[] = "H";
	char	to_find5[] = "J";
	char	src6[] = "uto Tata";
	char	to_find6[] = "ta";
	char	src7[] = "";
	char	to_find7[] = "42";

	printf("\"%s\" contient \"%s\" depuis :\n", src1, to_find1);
	printf("\"%s\" (\"%s\")\n", ft_strstr(src1, to_find1), strstr(src1, to_find1));
	printf("\"%s\" contient \"%s\" depuis :\n", src2, to_find2);
	printf("\"%s\ (\"%s\")\n", ft_strstr(src2, to_find2), strstr(src2, to_find2));
	printf("\"%s\" contient \"%s\" depuis :\n", src3, to_find3);
	printf("\"%s\ (\"%s\")\n", ft_strstr(src3, to_find3), strstr(src3, to_find3));
	printf("\"%s\" contient \"%s\" depuis :\n", src4, to_find4);
	printf("\"%s\ (\"%s\")\n", ft_strstr(src4, to_find4), strstr(src4, to_find4));
	printf("\"%s\" contient \"%s\" depuis :\n", src5, to_find5);
	printf("\"%s\ (\"%s\")\n", ft_strstr(src5, to_find5), strstr(src5, to_find5));
	printf("\"%s\" contient \"%s\" depuis :\n", src6, to_find6);
	printf("\"%s\ (\"%s\")\n", ft_strstr(src6, to_find6), strstr(src6, to_find6));
	printf("\"%s\" contient \"%s\" depuis :\n", src7, to_find7);
	printf("\"%s\ (\"%s\")\n", ft_strstr(src7, to_find7), strstr(src7, to_find7));
	return (0);
}
