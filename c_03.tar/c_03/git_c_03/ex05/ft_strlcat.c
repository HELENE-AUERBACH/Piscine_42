/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/17 11:11:29 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/17 11:33:01 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	int				i;
	int				j;
	unsigned int	dest_len;

	if (dest && src && size > 0)
	{
		i = 0;
		while (dest[i] != '\0')
			i++;
		dest_len = (unsigned int) i;
		j = 0;
		while ((unsigned int) j + dest_len < size && src[j] != '\0')
		{
			dest[i] = src[j];
			i++;
			j++;
		}
		if ((unsigned int) i <= size)
			dest[i] = '\0';
		return ((unsigned int) i);
	}
	return (0);
}
