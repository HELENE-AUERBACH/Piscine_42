/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_strcat.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/17 09:19:18 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/17 09:42:16 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strcat(char *dest, char *src);

int	main(void)
{
	char	src1[] = "";
	char	dest1[] = "";
	char	src2[] = "ABC";
	char	dest2[] = "";
	char	src3[] = "Toto Tata";
	char	dest3[] = "Titi";
	char	src4[] = "Tuto Tata";
	char	dest4[] = "Toiti           ";
	char	src5[1] = "2";
	char	dest5[1] = "H";

	printf("\"%s\" concatene a \"%s\" donne :\n", src1, dest1);
	printf("\"%s\"\n", ft_strcat(dest1, src1));
	printf("\"%s\" concatene a \"%s\" donne :\n", src2, dest2);
	printf("\"%s\"\n", ft_strcat(dest2, src2));
	printf("\"%s\" concatene a \"%s\" donne :\n", src3, dest3);
	printf("\"%s\"\n", ft_strcat(dest3, src3));
	printf("\"%s\" concatene a \"%s\" donne :\n", src4, dest4);
	printf("\"%s\"\n", ft_strcat(dest4, src4));
	printf("\"%s\" concatene a \"%s\" donne :\n", src5, dest5);
	printf("\"%s\"\n", ft_strcat(dest5, src5));
	return (0);
}
