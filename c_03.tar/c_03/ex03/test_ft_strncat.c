/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_strncat.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/17 10:01:25 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/17 10:01:29 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strncat(char *dest, char *src, unsigned int nb);

int	main(void)
{
	char	src1[] = "";
	char	dest1[] = "";
	char	src2[] = "ABC";
	char	dest2[] = "";
	char	src3[] = "Toto Tata";
	char	dest3[] = "Titi";
	char	src4[] = "Tuto Tata";
	char	dest4[] = "Toiti           ";
	char	src5[1] = "2";
	char	dest5[1] = "H";

	printf("\"%s\" concatene a \"%s\" pour n = %d donne :\n", src1, dest1, 0);
	printf("\"%s\"\n", ft_strncat(dest1, src1, 0));
	printf("\"%s\" concatene a \"%s\" pour n = %d donne :\n", src2, dest2, 3);
	printf("\"%s\"\n", ft_strncat(dest2, src2, 3));
	printf("\"%s\" concatene a \"%s\" pour n = %d donne :\n", src3, dest3, 12);
	printf("\"%s\"\n", ft_strncat(dest3, src3, 12));
	printf("\"%s\" concatene a \"%s\" pour n = %d donne :\n", src4, dest4, 9);
	printf("\"%s\"\n", ft_strncat(dest4, src4, 9));
	printf("\"%s\" concatene a \"%s\" pour n = %d donne :\n", src5, dest5, 1);
	printf("\"%s\"\n", ft_strncat(dest5, src5, 1));
	return (0);
}
