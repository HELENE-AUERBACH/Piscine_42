/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush00.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mpicardo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/11 17:23:58 by mpicardo          #+#    #+#             */
/*   Updated: 2023/02/11 17:24:06 by mpicardo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	ft_rush_horizontal_line(int x)
{
	if (x > 0)
	{
		ft_putchar('o');
		if (x >= 2)
		{
			x = x - 2;
			while (x > 0)
			{
				ft_putchar('-');
				x--;
			}
			ft_putchar('o');
		}
		ft_putchar('\n');
	}
}

void	ft_rush_vertical_line(int x)
{
	if (x > 0)
	{
		ft_putchar('|');
		if (x >= 2)
		{
			x = x - 2;
			while (x > 0)
			{
				ft_putchar(' ');
				x--;
			}
			ft_putchar('|');
		}
		ft_putchar('\n');
	}
}

void	ft_rush_vertical_lines(int y, int x)
{
	if (y > 0)
	{
		while (y > 0)
		{
			ft_rush_vertical_line(x);
			y--;
		}
	}
}

void	rush(int x, int y)
{
	if (x > 0 && y > 0)
	{
		ft_rush_horizontal_line(x);
		y = y - 2;
		if (y > 0)
		{
			ft_rush_vertical_lines(y, x);
		}
		if (y >= 0)
		{
			ft_rush_horizontal_line(x);
		}
	}
}
