/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush01.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mpicardo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/11 17:34:04 by mpicardo          #+#    #+#             */
/*   Updated: 2023/02/11 17:44:16 by mpicardo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	ft_rush_horizontal_line1(int x)
{
	if (x > 0)
	{
		ft_putchar('/');
		if (x >= 2)
		{
			x = x - 2;
			while (x > 0)
			{
				ft_putchar('*');
				x--;
			}
			ft_putchar('\\');
		}
		ft_putchar('\n');
	}
}

void	ft_rush_horizontal_line2(int x)
{
	if (x > 0)
	{
		ft_putchar('\\');
		if (x >= 2)
		{
			x = x - 2;
			while (x > 0)
			{
				ft_putchar('*');
				x--;
			}
			ft_putchar('/');
		}
		ft_putchar('\n');
	}
}

void	ft_rush_vertical_line(int x)
{
	if (x > 0)
	{
		ft_putchar('*');
		if (x >= 2)
		{
			x = x - 2;
			while (x > 0)
			{
				ft_putchar(' ');
				x--;
			}
			ft_putchar('*');
		}
		ft_putchar('\n');
	}
}

void	ft_rush_vertical_lines(int y, int x)
{
	if (y > 0)
	{
		while (y > 0)
		{
			ft_rush_vertical_line(x);
			y--;
		}
	}
}

void	rush(int x, int y)
{
	if (x > 0 && y > 0)
	{
		ft_rush_horizontal_line1(x);
		y = y - 2;
		if (y > 0)
		{
			ft_rush_vertical_lines(y, x);
		}
		if (y >= 0)
		{
			ft_rush_horizontal_line2(x);
		}
	}
}
