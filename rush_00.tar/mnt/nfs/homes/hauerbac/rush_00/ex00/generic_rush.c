/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   generic_rush.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mpicardo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/11 16:46:46 by mpicardo          #+#    #+#             */
/*   Updated: 2023/02/11 16:48:45 by mpicardo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	ft_rush_horizontal_line(int x, char character1, char character2,
		char character3)
{
	if (x > 0)
	{
		ft_putchar(character1);
		if (x >= 2)
		{
			x = x - 2;
			while (x > 0)
			{
				ft_putchar(character2);
				x--;
			}
			ft_putchar(character3);
		}
		ft_putchar('\n');
	}
}

void	ft_rush_vertical_line(int x, char character4)
{
	if (x > 0)
	{
		ft_putchar(character4);
		if (x >= 2)
		{
			x = x - 2;
			while (x > 0)
			{
				ft_putchar(' ');
				x--;
			}
			ft_putchar(character4);
		}
		ft_putchar('\n');
	}
}

void	ft_rush_vertical_lines(int y, int x, char character4)
{
	if (y > 0)
	{
		while (y > 0)
		{
			ft_rush_vertical_line(x, character4);
			y--;
		}
	}
}

void	rush(int x, int y, char character1, char character2,
		char character3, char character4, char character5,
		char character6)
{
	if (x > 0 && y > 0)
	{
		ft_rush_horizontal_line(x, character1, character2, character3);
		y = y - 2;
		if (y > 0)
		{
			ft_rush_vertical_lines(y, x, character4);
		}
		if (y >= 0)
		{
			ft_rush_horizontal_line(x, character5, character2, character6);
		}
	}
}
