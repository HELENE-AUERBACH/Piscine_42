/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   generic_main.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mpicardo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/11 15:13:53 by mpicardo          #+#    #+#             */
/*   Updated: 2023/02/11 17:06:10 by mpicardo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);
void	rush(int x, int y, char character1, char character2, char character3,
		char character4, char character5, char character6);

int	main(void)
{
	int	x;
	int	y;
	char	character1;
	char	character2;
	char	character3;
	char	character4;
	char	character5;
	char	character6;

	x = 5;
	y = 3;
	character1 = 'o';
	character2 = '-';
	character3 = 'o';
	character4 = '|';
	character5 = 'o';
	character6 = 'o';
	rush(x, y, character1, character2, character3, character4, character5,
		character6);
	ft_putchar('\n');
	character1 = '/';
	character2 = '*';
	character3 = '\\';
	character4 = '*';
	character5 = '\\';
	character6 = '/';
	rush(x, y, character1, character2, character3, character4, character5,
		character6);
	ft_putchar('\n');
	character1 = 'A';
	character2 = 'B';
	character3 = 'A';
	character4 = 'B';
	character5 = 'C';
	character6 = 'C';
	rush(x, y, character1, character2, character3, character4, character5,
		character6);
	ft_putchar('\n');
	character1 = 'A';
	character2 = 'B';
	character3 = 'C';
	character4 = 'B';
	character5 = 'A';
	character6 = 'C';
	rush(x, y, character1, character2, character3, character4, character5,
		character6);
	ft_putchar('\n');
	character1 = 'A';
	character2 = 'B';
	character3 = 'C';
	character4 = 'B';
	character5 = 'C';
	character6 = 'A';
	rush(x, y, character1, character2, character3, character4, character5,
		character6);
	return (0);
}
