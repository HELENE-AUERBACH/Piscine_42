#!/bin/bash
git ls-files -oi --exclude-standar