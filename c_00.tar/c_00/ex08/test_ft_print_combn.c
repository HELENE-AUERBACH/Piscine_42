/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_print_combn.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/13 19:16:06 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/13 19:16:11 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_combn(int n);

int	main(void)
{
	write(1, "n = 2 :\n", 8);
	ft_print_combn(2);
	write(1, "\n", 1);
	write(1, "n = 1 :\n", 8);
	ft_print_combn(1);
	write(1, "\n", 1);
	write(1, "n = 3 :\n", 8);
	ft_print_combn(3);
	write(1, "\n", 1);
	return (0);
}
