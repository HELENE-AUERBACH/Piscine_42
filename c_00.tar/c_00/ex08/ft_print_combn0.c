#include <unistd.h>

void	ft_print_n_digits(int n, int *digits)
{
	char	digits_into_characters[n + 1];
	int	i;

	if (digits[n - 1] > n - 1)
	{
		write(1, ", ", 2);
	}
	i = 0;
	while (i < n)
	{
		digits_into_characters[i] = digits[i] + '0';
		i++;
	}
	digits_into_characters[i] = '\0';
	write(1, digits_into_characters, n);
}

void	ft_print_combn(int n)
{
	int	i;
	int	j;
	int	digits[10];

	i = 0;
	digits[0] = 0;
	while (digits[0] < 10 - n + 1)
	{
		while (i < n)
		{
			digits[i + 1] = digits[i] + 1;
			while (second_digit < 9)
			{
				third_digit = second_digit + 1;
				while (third_digit <= 9)
				{
					ft_print_n_digits(n, digits);
					third_digit++;
				}
				second_digit++;
			}
			first_digit++;
		}
	}
}
