/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_combn.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/13 19:16:53 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/13 20:06:56 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_n_digits(int n, int *digits)
{
	char	digits_into_characters[10];
	int		i;

	if (digits[n - 1] > 1)
	{
		write(1, ", ", 2);
	}
	i = 0;
	while (i < n)
	{
		digits_into_characters[i] = digits[i] + '0';
		i++;
	}
	digits_into_characters[i] = '\0';
	write(1, digits_into_characters, n + 1);
}

void	ft_combn(int n, int *digits, int current)
{
	int	previous;

	while (current >= 0 && digits[0] < 10 - n + 1)
	{
		while (digits[n - 1] < 10)
		{
			ft_print_n_digits(n, digits);
			digits[n - 1] = digits[n - 1] + 1;
		}
		if (current == n - 1 || digits[current] == 9 - n + 1 + current)
			current--;
		if (current >= 0)
		{
			previous = current + 1;
			if (digits[previous] == 9 - n + 1 + previous)
			{
				digits[current] = digits[current] + 1;
				digits[previous] = digits[previous - 1] + 1;
			}
			else
				digits[previous] = digits[previous] + 1;
			previous++;
			while (current < n - 1 && previous < n)
			{
				digits[previous] = digits[previous - 1] + 1;
				previous++;
			}
			ft_combn(n, digits, current);
		}
	}
}

void	ft_print_combn(int n)
{
	int	i;
	int	digits[9];

	if (n > 0 && n < 10)
	{
		i = 0;
		digits[i] = 0;
		while (i < n - 1)
		{
			digits[i + 1] = digits[i] + 1;
			i++;
		}
		ft_combn(n, digits, n - 1);
	}
}
