void	ft_putchar(char c);

void	ft_print_comb2(void)
{
	int	a;
	int	b;

	a = 0;
	b = 0;
	while (b <= 98)
	{
		a = b + 1;
		while (a <= 99)
		{
			ft_putchar('0' + b / 10);
			ft_putchar('0' + b % 10);
			ft_putchar(' ');
			ft_putchar('0' + a / 10);
			ft_putchar('0' + a % 10);
			if (!(b == 98 && a == 99))
			{
				ft_putchar(',');
				ft_putchar(' ');
			}
			a++;
		}
		b++;
	}
}

int	main(void)
{
	ft_print_comb2();
	return (0);
}
