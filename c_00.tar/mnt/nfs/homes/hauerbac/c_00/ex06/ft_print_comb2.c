/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/09 19:15:25 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/09 19:15:29 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_digits(int first_digit, int second_digit, char separator)
{
	char	digits[3];

	digits[0] = first_digit + '0';
	digits[1] = second_digit + '0';
	digits[2] = '\0';
	write(1, digits, 3);
	if (separator != '\0')
	{
		write(1, &separator, 1);
	}
	if (separator == ',')
	{
		write(1, " ", 1);
	}
}

void	ft_print_comb(int first_digit_for_first_number,
		int second_digit_for_first_number,
		int first_digit_for_second_number,
		int second_digit_for_second_number)
{
	ft_print_digits(first_digit_for_first_number,
		second_digit_for_first_number,
		' ');
	if (first_digit_for_first_number == 9
		&& second_digit_for_first_number == 8
		&& first_digit_for_second_number == 9
		&& second_digit_for_second_number == 9)
	{
		ft_print_digits(first_digit_for_second_number,
			second_digit_for_second_number,
			'\0');
	}
	else
	{	
		ft_print_digits(first_digit_for_second_number,
			second_digit_for_second_number,
			',');
	}
}

void	ft_loop(int first_digit_for_first_number,
		int second_digit_for_first_number)
{
	int	first_digit_for_second_number;
	int	second_digit_for_second_number;

	first_digit_for_second_number = first_digit_for_first_number;
	second_digit_for_second_number = second_digit_for_first_number + 1;
	while (first_digit_for_second_number <= 9)
	{
		ft_print_comb(first_digit_for_first_number,
			second_digit_for_first_number,
			first_digit_for_second_number,
			second_digit_for_second_number);
		second_digit_for_second_number++;
		if (second_digit_for_second_number > 9)
		{
			first_digit_for_second_number++;
			second_digit_for_second_number = 0;
		}
	}
}

void	ft_print_comb2(void)
{
	int	first_digit_for_first_number;
	int	second_digit_for_first_number;

	first_digit_for_first_number = 0;
	second_digit_for_first_number = 0;
	while (first_digit_for_first_number < 9
		|| (first_digit_for_first_number == 9
			&& second_digit_for_first_number < 9))
	{
		ft_loop(first_digit_for_first_number,
			second_digit_for_first_number);
		second_digit_for_first_number++;
		if (second_digit_for_first_number > 9)
		{
			first_digit_for_first_number++;
			second_digit_for_first_number = 0;
		}
	}
}
