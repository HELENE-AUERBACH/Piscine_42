/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_ft_print_comb.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauerbac <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/09 12:16:54 by hauerbac          #+#    #+#             */
/*   Updated: 2023/02/09 12:16:58 by hauerbac         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_digits(int first_digit, int second_digit, int third_digit)
{
	char	digits[4];

	if (third_digit > 2)
	{
		write(1, ", ", 2);
	}
	digits[0] = first_digit + '0';
	digits[1] = second_digit + '0';
	digits[2] = third_digit + '0';
	digits[3] = '\0';
	write(1, digits, 3);
}

void	ft_print_comb(void)
{
	int	first_digit;
	int	second_digit;
	int	third_digit;

	first_digit = 0;
	while (first_digit < 8)
	{
		second_digit = first_digit + 1;
		while (second_digit < 9)
		{
			third_digit = second_digit + 1;
			while (third_digit <= 9)
			{
				ft_print_digits(first_digit, second_digit, third_digit);
				third_digit++;
			}
			second_digit++;
		}
		first_digit++;
	}
}

int	main(void)
{
	ft_print_comb();
	return (0);
}
